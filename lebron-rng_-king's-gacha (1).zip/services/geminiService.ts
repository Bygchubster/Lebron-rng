
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFlavorText = async (playerName: string, rarity: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a short, hype, 1-sentence flavor text for pulling a ${rarity} version of ${playerName} in an NBA RNG game. Make it sound exciting and meme-y if possible.`,
    });
    return response.text || "A legendary pull!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The courts tremble at your luck!";
  }
};
