
export enum Rarity {
  COMMON = 'Common',
  UNCOMMON = 'Uncommon',
  RARE = 'Rare',
  EPIC = 'Epic',
  LEGENDARY = 'Legendary',
  MYTHIC = 'Mythic',
  CELESTIAL = 'Celestial',
  DIVINE = 'Divine',
  GOAT = 'GOAT'
}

export interface Player {
  id: string;
  name: string;
  rarity: Rarity;
  odds: number; // 1 in X
  color: string;
  glowColor: string;
  image: string;
  flavor?: string;
}

export interface UserStats {
  coins: number;
  luckMultiplier: number;
  totalRolls: number;
  inventory: Player[];
  equipped: Player[];
  luckUpgrades: number;
  activePotions: {
    luck: number; // timestamp until expiry
    money: number; // timestamp until expiry
  };
}

export interface Potion {
  id: string;
  name: string;
  type: 'luck' | 'money';
  multiplier: number;
  duration: number; // in milliseconds
  price: number;
  color: string;
}
