
import { Rarity, Player, Potion } from './types';

export const RARITY_CONFIG = {
  [Rarity.COMMON]: { color: 'text-gray-400', glow: 'shadow-gray-500/50', bg: 'bg-gray-800' },
  [Rarity.UNCOMMON]: { color: 'text-green-400', glow: 'shadow-green-500/50', bg: 'bg-green-900/40' },
  [Rarity.RARE]: { color: 'text-blue-400', glow: 'shadow-blue-500/50', bg: 'bg-blue-900/40' },
  [Rarity.EPIC]: { color: 'text-purple-400', glow: 'shadow-purple-500/50', bg: 'bg-purple-900/40' },
  [Rarity.LEGENDARY]: { color: 'text-yellow-400', glow: 'shadow-yellow-500/50', bg: 'bg-yellow-900/40' },
  [Rarity.MYTHIC]: { color: 'text-red-500', glow: 'shadow-red-500/50', bg: 'bg-red-900/40' },
  [Rarity.CELESTIAL]: { color: 'text-cyan-400', glow: 'shadow-cyan-500/50', bg: 'bg-cyan-900/40' },
  [Rarity.DIVINE]: { color: 'text-pink-400', glow: 'shadow-pink-500/50', bg: 'bg-pink-900/40' },
  [Rarity.GOAT]: { color: 'text-white font-bold tracking-widest', glow: 'shadow-white/80', bg: 'bg-gradient-to-r from-orange-500 via-white to-orange-500' },
};

/**
 * Stable image URL for LeBron. 
 * Using a reliable Wikimedia thumbnail URL which is generally better for hotlinking.
 */
const LEBRON_IMAGE = 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/LeBron_James_crop.jpg/800px-LeBron_James_crop.jpg';

export const PLAYERS: Player[] = [
  { id: 'lb1', name: 'Baby LeBron', rarity: Rarity.COMMON, odds: 2, color: 'text-gray-400', glowColor: 'gray', image: LEBRON_IMAGE },
  { id: 'lb2', name: 'Draft Day LeBron', rarity: Rarity.COMMON, odds: 5, color: 'text-gray-400', glowColor: 'gray', image: LEBRON_IMAGE },
  { id: 'lb3', name: 'High School LeBron', rarity: Rarity.UNCOMMON, odds: 15, color: 'text-green-400', glowColor: 'green', image: LEBRON_IMAGE },
  { id: 'lb4', name: 'Masked LeBron', rarity: Rarity.UNCOMMON, odds: 25, color: 'text-green-400', glowColor: 'green', image: LEBRON_IMAGE },
  { id: 'lb5', name: 'Taco Tuesday LeBron', rarity: Rarity.RARE, odds: 50, color: 'text-blue-400', glowColor: 'blue', image: LEBRON_IMAGE },
  { id: 'lb6', name: 'Headband LeBron', rarity: Rarity.RARE, odds: 100, color: 'text-blue-400', glowColor: 'blue', image: LEBRON_IMAGE },
  { id: 'lb7', name: 'Miami Heat LeBron', rarity: Rarity.EPIC, odds: 250, color: 'text-purple-400', glowColor: 'purple', image: LEBRON_IMAGE },
  { id: 'lb8', name: 'Space Jam LeBron', rarity: Rarity.EPIC, odds: 500, color: 'text-purple-400', glowColor: 'purple', image: LEBRON_IMAGE },
  { id: 'lb9', name: 'The Silencer LeBron', rarity: Rarity.LEGENDARY, odds: 1000, color: 'text-yellow-400', glowColor: 'yellow', image: LEBRON_IMAGE },
  { id: 'lb10', name: 'King James', rarity: Rarity.LEGENDARY, odds: 2500, color: 'text-yellow-400', glowColor: 'yellow', image: LEBRON_IMAGE },
  { id: 'lb11', name: 'LePookie Bear', rarity: Rarity.LEGENDARY, odds: 5000, color: 'text-yellow-400', glowColor: 'yellow', image: LEBRON_IMAGE },
  { id: 'lb12', name: 'Skibidi LeBron', rarity: Rarity.MYTHIC, odds: 10000, color: 'text-red-500', glowColor: 'red', image: LEBRON_IMAGE },
  { id: 'lb13', name: 'You Are My Sunshine LeBron', rarity: Rarity.MYTHIC, odds: 25000, color: 'text-red-500', glowColor: 'red', image: LEBRON_IMAGE },
  { id: 'lb14', name: 'Mewing LeBron', rarity: Rarity.MYTHIC, odds: 50000, color: 'text-red-500', glowColor: 'red', image: LEBRON_IMAGE },
  { id: 'lb15', name: 'Cybernetic LeBron 3000', rarity: Rarity.CELESTIAL, odds: 100000, color: 'text-cyan-400', glowColor: 'cyan', image: LEBRON_IMAGE },
  { id: 'lb16', name: 'The Chosen One (Ascended)', rarity: Rarity.DIVINE, odds: 500000, color: 'text-pink-400', glowColor: 'pink', image: LEBRON_IMAGE },
  { id: 'lb17', name: 'Gold LeBron (Statue)', rarity: Rarity.GOAT, odds: 1000000, color: 'text-white', glowColor: 'white', image: LEBRON_IMAGE },
  { id: 'lb18', name: 'Literal Goat LeBron', rarity: Rarity.GOAT, odds: 5000000, color: 'text-white', glowColor: 'white', image: LEBRON_IMAGE },
  { id: 'lb19', name: 'Universe 23 LeBron', rarity: Rarity.GOAT, odds: 10000000, color: 'text-white', glowColor: 'white', image: LEBRON_IMAGE },
];

export const POTIONS: Potion[] = [
  { id: 'p1', name: 'Minor Luck Potion', type: 'luck', multiplier: 10, duration: 60000, price: 500, color: 'from-green-400 to-green-600' },
  { id: 'p2', name: 'Major Luck Potion', type: 'luck', multiplier: 50, duration: 300000, price: 2500, color: 'from-blue-400 to-blue-600' },
  { id: 'p3', name: 'Hyper Luck Potion', type: 'luck', multiplier: 250, duration: 600000, price: 10000, color: 'from-purple-400 to-purple-600' },
  { id: 'p4', name: 'Cash Infusion', type: 'money', multiplier: 10, duration: 120000, price: 1000, color: 'from-yellow-400 to-yellow-600' },
];

export const LUCK_UPGRADE_COSTS = [25, 100, 500, 2000, 10000, 50000, 250000, 1000000, 5000000];
