
import React from 'react';
import { Player, Rarity } from '../types';
import { RARITY_CONFIG } from '../constants';

interface InventoryModalProps {
  inventory: Player[];
  equipped: Player[];
  onEquip: (player: Player) => void;
  onClose: () => void;
}

const InventoryModal: React.FC<InventoryModalProps> = ({ inventory, equipped, onEquip, onClose }) => {
  // Sort inventory by rarity odds
  const sortedInventory = [...inventory].sort((a, b) => b.odds - a.odds);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-neutral-900 w-full max-w-4xl max-h-[80vh] rounded-3xl border border-white/10 flex flex-col overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-white/10 flex justify-between items-center">
          <h2 className="text-2xl font-bungee text-white">COLLECTION ({inventory.length})</h2>
          <button onClick={onClose} className="text-neutral-500 hover:text-white text-2xl">×</button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {sortedInventory.map((player) => {
              const config = RARITY_CONFIG[player.rarity];
              const isEquipped = equipped.some(e => e.id === player.id);
              
              return (
                <div 
                  key={player.id}
                  className={`relative aspect-[3/4] rounded-xl border p-2 flex flex-col transition-all cursor-pointer group ${
                    isEquipped ? 'border-orange-500 bg-orange-500/10' : 'border-white/5 bg-white/5 hover:border-white/20'
                  }`}
                  onClick={() => onEquip(player)}
                >
                  <div className="flex-1 rounded-lg overflow-hidden mb-2">
                    <img src={player.image} alt={player.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="text-center">
                    <p className={`text-[10px] font-bold uppercase truncate ${config.color}`}>
                      {player.rarity}
                    </p>
                    <p className="text-xs font-bold text-white truncate px-1">
                      {player.name}
                    </p>
                  </div>
                  {isEquipped && (
                    <div className="absolute top-2 right-2 bg-orange-500 text-[8px] font-bold px-1.5 py-0.5 rounded shadow-lg">
                      EQUIPPED
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {inventory.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-neutral-500 uppercase tracking-widest">
              <p>Nothing in your locker yet</p>
              <p className="text-xs mt-2">Go roll some legends!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InventoryModal;
