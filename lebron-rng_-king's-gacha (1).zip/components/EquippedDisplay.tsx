
import React from 'react';
import { Player } from '../types';
import { RARITY_CONFIG } from '../constants';

interface EquippedDisplayProps {
  equipped: Player[];
}

const FALLBACK_IMAGE = 'https://media.gettyimages.com/id/1247065095/photo/lebron-james-of-the-los-angeles-lakers-reacts-during-a-game.jpg?s=612x612&w=gi&k=20&c=W07_U7f1Bv0yB8hC1E0yB8hC1E0yB8hC1E0yB8hC1E0=';

const EquippedDisplay: React.FC<EquippedDisplayProps> = ({ equipped }) => {
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    (e.target as HTMLImageElement).src = FALLBACK_IMAGE;
  };

  return (
    <div className="flex gap-4 items-center">
      <div className="flex gap-3">
        {[0, 1, 2].map((i) => {
          const player = equipped[i];
          const config = player ? RARITY_CONFIG[player.rarity] : null;

          return (
            <div 
              key={i} 
              className={`w-14 h-14 md:w-20 md:h-20 rounded-2xl border-2 flex items-center justify-center overflow-hidden transition-all shadow-lg ${
                player ? `border-current ${config?.color} bg-neutral-800` : 'border-dashed border-white/10 bg-white/5'
              }`}
            >
              {player ? (
                <img 
                  src={player.image} 
                  alt={player.name} 
                  className="w-full h-full object-cover" 
                  onError={handleImageError}
                />
              ) : (
                <span className="text-white/5 text-3xl font-bungee">+</span>
              )}
            </div>
          );
        })}
      </div>
      <div className="ml-2 bg-white/5 px-4 py-2 rounded-xl border border-white/10">
        <p className="text-[10px] font-bold text-neutral-400 uppercase">Passive Income</p>
        <p className="text-lg font-bungee text-green-500 leading-none">+${(equipped.length * 100 + 10)}/s</p>
      </div>
    </div>
  );
};

export default EquippedDisplay;
