
import React from 'react';
import { POTIONS, LUCK_UPGRADE_COSTS } from '../constants';
import { Potion } from '../types';

interface ShopModalProps {
  coins: number;
  luckLevel: number;
  onUpgradeLuck: () => void;
  onBuyPotion: (potion: Potion) => void;
  onClose: () => void;
}

const ShopModal: React.FC<ShopModalProps> = ({ coins, luckLevel, onUpgradeLuck, onBuyPotion, onClose }) => {
  const nextLuckCost = LUCK_UPGRADE_COSTS[luckLevel];
  const canAffordLuck = nextLuckCost !== undefined && coins >= nextLuckCost;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-neutral-900 w-full max-w-2xl rounded-3xl border border-white/10 flex flex-col overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
          <div>
            <h2 className="text-2xl font-bungee text-white">THE PRO SHOP</h2>
            <p className="text-sm text-yellow-500 font-bold">Balance: ${coins.toLocaleString()}</p>
          </div>
          <button onClick={onClose} className="text-neutral-500 hover:text-white text-2xl">×</button>
        </div>

        <div className="p-6 space-y-8 overflow-y-auto max-h-[70vh]">
          {/* Permanent Upgrades */}
          <div>
            <h3 className="text-sm font-bold text-neutral-400 uppercase tracking-widest mb-4">Permanent Upgrades</h3>
            <div className="bg-white/5 border border-white/10 p-4 rounded-2xl flex items-center justify-between group">
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center text-green-500 text-2xl">
                  🍀
                </div>
                <div>
                  <p className="font-bold text-white">Luck Mastery (Level {luckLevel})</p>
                  <p className="text-xs text-neutral-400">Increases permanent luck by +0.5x</p>
                </div>
              </div>
              <button 
                onClick={onUpgradeLuck}
                disabled={!canAffordLuck}
                className={`px-6 py-3 rounded-xl font-bold transition-all ${
                  canAffordLuck 
                    ? 'bg-orange-600 hover:bg-orange-500 text-white' 
                    : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                }`}
              >
                {nextLuckCost !== undefined ? `$${nextLuckCost.toLocaleString()}` : 'MAX'}
              </button>
            </div>
          </div>

          {/* Potions */}
          <div>
            <h3 className="text-sm font-bold text-neutral-400 uppercase tracking-widest mb-4">Temporary Boosts</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {POTIONS.map(potion => (
                <div key={potion.id} className="bg-white/5 border border-white/10 p-4 rounded-2xl flex flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${potion.color} flex items-center justify-center text-xl shadow-lg shadow-black/40`}>
                      {potion.type === 'luck' ? '🔮' : '💰'}
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm">{potion.name}</p>
                      <p className="text-[10px] text-neutral-400">{Math.floor(potion.duration / 60000)}m Duration</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-yellow-500 font-bold text-sm">${potion.price.toLocaleString()}</span>
                    <button 
                      onClick={() => onBuyPotion(potion)}
                      disabled={coins < potion.price}
                      className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        coins >= potion.price 
                          ? 'bg-white/10 hover:bg-white/20 text-white' 
                          : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                      }`}
                    >
                      Buy
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShopModal;
