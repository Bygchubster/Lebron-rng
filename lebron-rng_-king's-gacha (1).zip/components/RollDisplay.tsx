
import React from 'react';
import { Player, Rarity } from '../types';
import { RARITY_CONFIG } from '../constants';

interface RollDisplayProps {
  player: Player | null;
  isRolling: boolean;
  flavor: string;
}

const FALLBACK_IMAGE = 'https://media.gettyimages.com/id/1247065095/photo/lebron-james-of-the-los-angeles-lakers-reacts-during-a-game.jpg?s=612x612&w=gi&k=20&c=W07_U7f1Bv0yB8hC1E0yB8hC1E0yB8hC1E0yB8hC1E0=';

const RollDisplay: React.FC<RollDisplayProps> = ({ player, isRolling, flavor }) => {
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    const target = e.target as HTMLImageElement;
    if (target.src !== FALLBACK_IMAGE) {
      target.src = FALLBACK_IMAGE;
    }
  };

  if (isRolling) {
    return (
      <div className="h-96 flex flex-col items-center justify-center">
        <div className="relative w-32 h-32">
          <div className="absolute inset-0 border-8 border-orange-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-8 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center text-4xl animate-bounce">
            🏀
          </div>
        </div>
        <p className="mt-8 text-xl font-bungee text-white tracking-widest animate-pulse">
          GETTING BUCKETS...
        </p>
      </div>
    );
  }

  if (!player) {
    return (
      <div className="h-96 flex items-center justify-center">
        <div className="text-neutral-500 text-lg uppercase tracking-widest opacity-50 flex flex-col items-center gap-4">
          <span className="text-6xl animate-pulse">👑</span>
          <span>Click Roll</span>
        </div>
      </div>
    );
  }

  const config = RARITY_CONFIG[player.rarity];

  const getFilter = (rarity: Rarity) => {
    switch (rarity) {
      case Rarity.COMMON: return 'grayscale(100%) brightness(0.8)';
      case Rarity.RARE: return 'hue-rotate(200deg) saturate(2)';
      case Rarity.EPIC: return 'hue-rotate(280deg) saturate(2.5) contrast(1.2)';
      case Rarity.LEGENDARY: return 'sepia(0.5) brightness(1.2) saturate(3) contrast(1.1)';
      case Rarity.MYTHIC: return 'hue-rotate(340deg) saturate(4) contrast(1.5)';
      case Rarity.CELESTIAL: return 'hue-rotate(180deg) brightness(1.8) saturate(1.5) contrast(1.2)';
      case Rarity.DIVINE: return 'hue-rotate(300deg) brightness(1.5) contrast(1.6) saturate(2)';
      case Rarity.GOAT: return 'brightness(1.6) contrast(1.4) saturate(2.5) drop-shadow(0 0 15px white)';
      default: return 'none';
    }
  };

  return (
    <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300">
      <div className="text-center mb-6">
        <p className={`text-sm font-bold uppercase tracking-[0.3em] ${config.color} drop-shadow-lg`}>
          {player.rarity} 
          <span className="ml-2 text-white/40">1 in {player.odds.toLocaleString()}</span>
        </p>
      </div>
      
      <div className={`relative group w-72 h-96 rounded-3xl p-2 transition-all duration-700 bg-neutral-800 shadow-2xl ${config.glow}`}>
        <div className={`w-full h-full rounded-2xl overflow-hidden relative flex flex-col border-4 border-white/5 bg-neutral-900`}>
          <div className={`absolute top-0 left-0 w-full h-32 opacity-20 ${config.bg}`}></div>
          
          <div className="h-2/3 w-full relative z-10">
            <div className="w-full h-full bg-black/40 relative overflow-hidden">
              <img 
                src={player.image} 
                alt={player.name} 
                style={{ filter: getFilter(player.rarity) }}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                onError={handleImageError}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent"></div>
            </div>
          </div>
          
          <div className="p-4 flex-1 flex flex-col justify-center text-center z-10">
            <h2 className={`text-2xl font-bungee leading-tight mb-1 drop-shadow-md ${config.color}`}>
              {player.name}
            </h2>
            <div className="h-1 w-12 bg-white/20 mx-auto rounded-full"></div>
          </div>

          {player.odds >= 1000 && (
            <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl z-20">
              <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[radial-gradient(circle,rgba(255,255,255,0.15)_0%,transparent_70%)] animate-pulse"></div>
            </div>
          )}
        </div>
      </div>

      {flavor && (
        <p className="mt-8 text-center text-neutral-300 italic max-w-sm font-medium bg-neutral-800/80 backdrop-blur px-8 py-4 rounded-2xl border border-white/10 shadow-xl animate-in slide-in-from-bottom-4 duration-500">
          "{flavor}"
        </p>
      )}
    </div>
  );
};

export default RollDisplay;
