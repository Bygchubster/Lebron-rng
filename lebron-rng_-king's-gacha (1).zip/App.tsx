
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Rarity, Player, UserStats, Potion } from './types';
import { PLAYERS, POTIONS, LUCK_UPGRADE_COSTS, RARITY_CONFIG } from './constants';
import { getFlavorText } from './services/geminiService';

// Component helpers
import InventoryModal from './components/InventoryModal';
import ShopModal from './components/ShopModal';
import RollDisplay from './components/RollDisplay';
import EquippedDisplay from './components/EquippedDisplay';

const App: React.FC = () => {
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('lebron-rng-stats-v3');
    if (saved) return JSON.parse(saved);
    return {
      coins: 0,
      luckMultiplier: 1,
      totalRolls: 0,
      inventory: [],
      equipped: [],
      luckUpgrades: 0,
      activePotions: { luck: 0, money: 0 }
    };
  });

  const [lastRoll, setLastRoll] = useState<Player | null>(null);
  const [isRolling, setIsRolling] = useState(false);
  const [autoRoll, setAutoRoll] = useState(false);
  const [activeModal, setActiveModal] = useState<'inventory' | 'shop' | null>(null);
  const [currentFlavor, setCurrentFlavor] = useState("");

  const rollRef = useRef<boolean>(isRolling);
  rollRef.current = isRolling;

  // Persist stats
  useEffect(() => {
    localStorage.setItem('lebron-rng-stats-v3', JSON.stringify(stats));
  }, [stats]);

  // Periodic earnings
  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => {
        const moneyMult = prev.activePotions.money > Date.now() ? 10 : 1;
        // Supercharged income: Each equipped player gives 100/sec, base 10/sec
        const passiveIncome = (prev.equipped.length * 100 + 10) * moneyMult;
        return { ...prev, coins: prev.coins + passiveIncome };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const getCurrentLuck = useCallback(() => {
    // Massive Luck Gains: Each upgrade gives +5x luck
    let baseLuck = 1 + (stats.luckUpgrades * 5);
    
    let potionMultiplier = 1;
    if (stats.activePotions.luck > Date.now()) {
      // Potions are now 10x more effective
      potionMultiplier = 15; 
    }
    
    return baseLuck * potionMultiplier;
  }, [stats.luckUpgrades, stats.activePotions.luck]);

  const performRoll = useCallback(async () => {
    if (isRolling) return;
    setIsRolling(true);
    setCurrentFlavor("");

    const luck = getCurrentLuck();
    
    const sortedPlayers = [...PLAYERS].sort((a, b) => b.odds - a.odds);
    
    let selected: Player = PLAYERS[0];

    for (const player of sortedPlayers) {
      const chance = 1 / (player.odds / luck);
      if (Math.random() < chance) {
        selected = player;
        break;
      }
    }

    setLastRoll(selected);
    
    if (selected.odds >= 1000) {
      const flavor = await getFlavorText(selected.name, selected.rarity);
      setCurrentFlavor(flavor);
    }

    setStats(prev => {
      const exists = prev.inventory.some(p => p.id === selected.id);
      const newInventory = exists ? prev.inventory : [...prev.inventory, selected];
      return {
        ...prev,
        totalRolls: prev.totalRolls + 1,
        inventory: newInventory
      };
    });

    setTimeout(() => {
      setIsRolling(false);
    }, 250); // Blazing fast rolls
  }, [isRolling, getCurrentLuck]);

  useEffect(() => {
    let timer: any;
    if (autoRoll && !isRolling) {
      timer = setTimeout(() => {
        performRoll();
      }, 300); // Blazing fast auto-roll
    }
    return () => clearTimeout(timer);
  }, [autoRoll, isRolling, performRoll]);

  const buyUpgrade = () => {
    const cost = LUCK_UPGRADE_COSTS[stats.luckUpgrades];
    if (stats.coins >= cost && stats.luckUpgrades < LUCK_UPGRADE_COSTS.length) {
      setStats(prev => ({
        ...prev,
        coins: prev.coins - cost,
        luckUpgrades: prev.luckUpgrades + 1
      }));
    }
  };

  const buyPotion = (potion: Potion) => {
    if (stats.coins >= potion.price) {
      setStats(prev => ({
        ...prev,
        coins: prev.coins - potion.price,
        activePotions: {
          ...prev.activePotions,
          [potion.type]: Date.now() + potion.duration
        }
      }));
    }
  };

  const equipPlayer = (player: Player) => {
    setStats(prev => {
      const isEquipped = prev.equipped.some(p => p.id === player.id);
      if (isEquipped) {
        return { ...prev, equipped: prev.equipped.filter(p => p.id !== player.id) };
      }
      if (prev.equipped.length >= 3) return prev;
      return { ...prev, equipped: [...prev.equipped, player] };
    });
  };

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col items-center p-4 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-orange-500/10 rounded-full blur-[120px]"></div>

      <div className="w-full max-w-4xl flex justify-between items-start z-10">
        <div className="bg-black/40 backdrop-blur-md p-4 rounded-xl border border-white/10">
          <h1 className="text-3xl font-bungee text-orange-500 tracking-tight">LEBRON RNG</h1>
          <p className="text-sm text-neutral-400">Rolls: <span className="text-white">{stats.totalRolls.toLocaleString()}</span></p>
          <p className="text-sm text-neutral-400">Luck: <span className="text-green-400">x{getCurrentLuck().toFixed(1)}</span></p>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="bg-black/40 backdrop-blur-md p-4 rounded-xl border border-white/10 flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs text-neutral-400 uppercase font-bold">Balance</p>
              <p className="text-2xl font-bungee text-yellow-500">${stats.coins.toLocaleString()}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center text-black font-bold">$</div>
          </div>
          
          <div className="flex gap-2">
            {stats.activePotions.luck > Date.now() && (
              <div className="bg-purple-900/50 text-purple-200 text-[10px] px-2 py-1 rounded-full border border-purple-500/50 animate-pulse">LUCK BOOST</div>
            )}
            {stats.activePotions.money > Date.now() && (
              <div className="bg-yellow-900/50 text-yellow-200 text-[10px] px-2 py-1 rounded-full border border-yellow-500/50 animate-pulse">CASH BOOST</div>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-2xl z-10 py-12">
        <RollDisplay player={lastRoll} isRolling={isRolling} flavor={currentFlavor} />
        
        <div className="mt-12 flex flex-col items-center gap-6 w-full">
          <button
            onClick={performRoll}
            disabled={isRolling}
            className={`w-40 h-40 rounded-full font-bungee text-2xl transition-all duration-300 shadow-2xl relative group overflow-hidden ${
              isRolling ? 'bg-neutral-800 scale-95 cursor-not-allowed' : 'bg-orange-600 hover:bg-orange-500 hover:scale-110 active:scale-90 shadow-orange-500/20'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-white/20 to-transparent"></div>
            {isRolling ? '...' : 'ROLL'}
          </button>

          <div className="flex gap-4">
             <button
              onClick={() => setAutoRoll(!autoRoll)}
              className={`px-8 py-3 rounded-full font-bold border-2 transition-all ${
                autoRoll ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-white/5 border-white/20 text-white hover:bg-white/10'
              }`}
            >
              {autoRoll ? 'STOP AUTO' : 'AUTO ROLL'}
            </button>
          </div>
        </div>
      </div>

      <div className="w-full max-w-4xl z-20 flex flex-col md:flex-row justify-between items-center gap-4 bg-black/60 backdrop-blur-xl p-4 rounded-2xl border border-white/10 mt-auto sticky bottom-4">
        <EquippedDisplay equipped={stats.equipped} />
        <div className="flex gap-3">
          <button onClick={() => setActiveModal('inventory')} className="flex flex-col items-center px-6 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors">
            <span className="text-xs text-neutral-400">Locker</span>
            <span className="font-bold text-lg">{stats.inventory.length}</span>
          </button>
          <button onClick={() => setActiveModal('shop')} className="flex flex-col items-center px-6 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors">
            <span className="text-xs text-neutral-400">Shop</span>
            <span className="font-bold text-lg">🏪</span>
          </button>
        </div>
      </div>

      {activeModal === 'inventory' && <InventoryModal inventory={stats.inventory} equipped={stats.equipped} onEquip={equipPlayer} onClose={() => setActiveModal(null)} />}
      {activeModal === 'shop' && <ShopModal coins={stats.coins} luckLevel={stats.luckUpgrades} onUpgradeLuck={buyUpgrade} onBuyPotion={buyPotion} onClose={() => setActiveModal(null)} />}
    </div>
  );
};

export default App;
